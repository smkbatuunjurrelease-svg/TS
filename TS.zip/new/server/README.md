# Example server for Teacher Substitution System

This minimal Express server demonstrates how to accept requests from the client and persist them to `server/data/requests.json`.

Run (PowerShell):

```powershell
cd server
npm install
npm start
# server runs on http://localhost:3000
```

API endpoints:
 - `GET /api/teachers` — list teachers (file-backed)
 - `POST /api/teachers` — create new teacher (JSON body)
 - `PUT /api/teachers/:id` — update teacher
 - `DELETE /api/teachers/:id` — remove teacher

 Google Sheets sync (optional):
 You can configure the server to append teachers and requests to your Google Sheet. To enable this set the following environment variables before starting the server:
	- `GOOGLE_SHEET_ID` — the spreadsheet id used by `teacher.html` (the same one you used earlier)
	- Provide service account credentials either as a file path or as a raw JSON string:
		- `GOOGLE_SERVICE_ACCOUNT_FILE` — path to service account JSON key file on the server; or
		- `GOOGLE_SERVICE_ACCOUNT_KEY` — the raw JSON contents of the service account key (useful for CI or env-only setups).

 Example (PowerShell) using a key file:

 ```powershell
 $env:GOOGLE_SHEET_ID = 'your-sheet-id'
 $env:GOOGLE_SERVICE_ACCOUNT_FILE = 'C:\path\to\service-account.json'
 npm start
 ```

Example (PowerShell) using raw JSON in an env var (CI-friendly):

```powershell
$env:GOOGLE_SHEET_ID = 'your-sheet-id'
$env:GOOGLE_SERVICE_ACCOUNT_KEY = Get-Content -Raw 'C:\path\to\service-account.json'
npm start
```

Sync endpoint:
- `POST /api/sync` — append server JSON (`data/teachers.json` and `data/requests.json`) to the Google Sheet tabs `TeacherNameID` and `Form Responses 1`.
	- Optional query flags: `?clearTeachers=true&clearRequests=true` to clear the destination tabs before appending.

Notes on sync behavior:
- The sync operation appends rows. To avoid duplicates, either use the `clear` option or run deduplication on the sheet after sync.
- Ensure the service account has edit access to the spreadsheet and that the named tabs exist.
Notes:
 Notes:
 - This example appends rows to the `TeacherNameID` and `Form Responses 1` tabs when configured. Updating existing rows in Google Sheets reliably requires locating the row index; that is not implemented here and would need a mapping strategy (e.g., store the sheet row number alongside the object).
 - The example server is for development only. For production: add authentication, input validation, and use a proper database or the Google Sheets API with careful rate-limit handling.
- This is a demonstration only. For production use replace file-based storage with a database and add authentication.
