const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
// Defer requiring `googleapis` until it's actually needed so the server can start
// even if the module isn't installed (Google Sheets sync is optional).
const bodyParser = require('body-parser');

const DATA_DIR = path.join(__dirname, 'data');
const REQUESTS_FILE = path.join(DATA_DIR, 'requests.json');
const TEACHERS_FILE = path.join(DATA_DIR, 'teachers.json');

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR);
if (!fs.existsSync(REQUESTS_FILE)) fs.writeFileSync(REQUESTS_FILE, '[]');
if (!fs.existsSync(TEACHERS_FILE)) fs.writeFileSync(TEACHERS_FILE, '[]');

const app = express();
app.use(cors());
app.use(bodyParser.json());

function readJson(file) {
  return JSON.parse(fs.readFileSync(file, 'utf8') || '[]');
}

function writeJson(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

// Optional Google Sheets syncing
// To enable: set env var GOOGLE_SHEET_ID and provide a service account key JSON
// via GOOGLE_SERVICE_ACCOUNT_KEY (raw JSON string) or GOOGLE_SERVICE_ACCOUNT_FILE (path).
const GOOGLE_SHEET_ID = process.env.GOOGLE_SHEET_ID || '';
let sheetsClient = null;

async function initGoogleSheets() {
  if (!GOOGLE_SHEET_ID) return null;
  let auth;
  try {
      // Try to require googleapis here; if it's not installed, skip Sheets integration.
      let google;
      try {
        google = require('googleapis').google;
      } catch (err) {
        console.warn('googleapis module not available; Google Sheets sync disabled.');
        return null;
      }

      if (process.env.GOOGLE_SERVICE_ACCOUNT_KEY) {
        const key = JSON.parse(process.env.GOOGLE_SERVICE_ACCOUNT_KEY);
        auth = new google.auth.GoogleAuth({
          credentials: key,
          scopes: ['https://www.googleapis.com/auth/spreadsheets']
        });
      } else if (process.env.GOOGLE_SERVICE_ACCOUNT_FILE) {
        auth = new google.auth.GoogleAuth({
          keyFile: process.env.GOOGLE_SERVICE_ACCOUNT_FILE,
          scopes: ['https://www.googleapis.com/auth/spreadsheets']
        });
      } else {
        console.warn('Google Sheets credentials not provided; skipping sync.');
        return null;
      }
      const client = await auth.getClient();
      sheetsClient = google.sheets({ version: 'v4', auth: client });
      console.log('Google Sheets client initialized');
      return sheetsClient;
  } catch (err) {
    console.error('Failed to initialize Google Sheets client:', err.message || err);
    sheetsClient = null;
    return null;
  }
}

// Initialize sheets client but don't block startup
initGoogleSheets();

// --- Requests endpoints (file-backed) ---
app.get('/api/requests', (req, res) => {
  res.json(readJson(REQUESTS_FILE));
});

app.post('/api/requests', (req, res) => {
  const requests = readJson(REQUESTS_FILE);
  const item = req.body;
  requests.push(item);
  writeJson(REQUESTS_FILE, requests);

  // If Google Sheets is configured, optionally append to sheet (best-effort).
  if (sheetsClient && GOOGLE_SHEET_ID) {
    // The sheet name used in the client is `Form Responses 1` — append there.
    const values = [[
      item.id || '',
      item.teacherName || '',
      item.Teachers_ID || item.teacherId || '',
      item.date || '',
      item.time || '',
      item.subject || '',
      item.reason || '',
      item.status || '',
      item.substitute || '',
      item.timestamp || ''
    ]];
    sheetsClient.spreadsheets.values.append({
      spreadsheetId: GOOGLE_SHEET_ID,
      range: 'Form Responses 1',
      valueInputOption: 'USER_ENTERED',
      requestBody: { values }
    }).catch(err => console.warn('Failed to append request to Google Sheet:', err.message || err));
  }

  res.status(201).json(item);
});

app.put('/api/requests/:id', (req, res) => {
  const requests = readJson(REQUESTS_FILE);
  const idx = requests.findIndex(r => r.id === req.params.id);
  if (idx === -1) return res.status(404).send('Not found');
  requests[idx] = { ...requests[idx], ...req.body };
  writeJson(REQUESTS_FILE, requests);

  // Note: updating the corresponding row in Google Sheets reliably requires locating the row.
  // This example does not implement row lookup/overwrite — consider adding a Request_ID column and mapping.

  res.json(requests[idx]);
});

// --- Teachers endpoints ---
app.get('/api/teachers', (req, res) => {
  res.json(readJson(TEACHERS_FILE));
});

app.post('/api/teachers', (req, res) => {
  const teachers = readJson(TEACHERS_FILE);
  const item = req.body;
  // Ensure minimal shape
  item.id = item.id || (`TCHR${(teachers.length + 1).toString().padStart(3, '0')}`);
  item.name = item.name || 'Unknown';
  item.email = item.email || '';
  item.available = item.available !== undefined ? !!item.available : true;
  item.isAdmin = !!item.isAdmin;
  teachers.push(item);
  writeJson(TEACHERS_FILE, teachers);

  // Optionally append to Google Sheet TeacherNameID
  if (sheetsClient && GOOGLE_SHEET_ID) {
    const values = [[item.id, item.name, item.email]];
    sheetsClient.spreadsheets.values.append({
      spreadsheetId: GOOGLE_SHEET_ID,
      range: 'TeacherNameID',
      valueInputOption: 'USER_ENTERED',
      requestBody: { values }
    }).catch(err => console.warn('Failed to append teacher to Google Sheet:', err.message || err));
  }

  res.status(201).json(item);
});

app.put('/api/teachers/:id', (req, res) => {
  const teachers = readJson(TEACHERS_FILE);
  const idx = teachers.findIndex(t => t.id === req.params.id);
  if (idx === -1) return res.status(404).send('Not found');
  teachers[idx] = { ...teachers[idx], ...req.body };
  writeJson(TEACHERS_FILE, teachers);

  // Note: syncing updates back to Google Sheets would require locating the row. Not implemented here.

  res.json(teachers[idx]);
});

app.delete('/api/teachers/:id', (req, res) => {
  let teachers = readJson(TEACHERS_FILE);
  const idx = teachers.findIndex(t => t.id === req.params.id);
  if (idx === -1) return res.status(404).send('Not found');
  const removed = teachers.splice(idx, 1)[0];
  writeJson(TEACHERS_FILE, teachers);
  res.json(removed);
});

// Sync server JSON data to Google Sheets (best-effort)
app.post('/api/sync', async (req, res) => {
  if (!sheetsClient || !GOOGLE_SHEET_ID) return res.status(400).send('Google Sheets not configured on server');
  try {
    const teachers = readJson(TEACHERS_FILE);
    const requests = readJson(REQUESTS_FILE);

    // Optional clear flags: ?clearTeachers=true&clearRequests=true or in body
    const clearTeachers = (req.query.clearTeachers === 'true') || (req.body && req.body.clearTeachers);
    const clearRequests = (req.query.clearRequests === 'true') || (req.body && req.body.clearRequests);

    if (clearTeachers) {
      await sheetsClient.spreadsheets.values.clear({ spreadsheetId: GOOGLE_SHEET_ID, range: 'TeacherNameID' });
    }
    if (clearRequests) {
      await sheetsClient.spreadsheets.values.clear({ spreadsheetId: GOOGLE_SHEET_ID, range: 'Form Responses 1' });
    }

    // Append teachers
    const teacherValues = teachers.map(t => [t.id || '', t.name || '', t.email || '']);
    if (teacherValues.length) {
      await sheetsClient.spreadsheets.values.append({
        spreadsheetId: GOOGLE_SHEET_ID,
        range: 'TeacherNameID',
        valueInputOption: 'USER_ENTERED',
        requestBody: { values: teacherValues }
      });
    }

    // Append requests
    const requestValues = requests.map(r => [
      r.id || '',
      r.teacherName || '',
      r.teacherId || r.Teachers_ID || '',
      r.date || '',
      r.time || '',
      r.subject || '',
      r.reason || '',
      r.status || '',
      r.substitute || '',
      r.timestamp || ''
    ]);
    if (requestValues.length) {
      await sheetsClient.spreadsheets.values.append({
        spreadsheetId: GOOGLE_SHEET_ID,
        range: 'Form Responses 1',
        valueInputOption: 'USER_ENTERED',
        requestBody: { values: requestValues }
      });
    }

    res.json({ ok: true, teachers: teacherValues.length, requests: requestValues.length });
  } catch (err) {
    console.error('Sync to Google Sheets failed:', err.message || err);
    res.status(500).json({ ok: false, error: err.message || String(err) });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
