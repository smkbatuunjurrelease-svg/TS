const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, 'data');
const DATA_FILE = path.join(DATA_DIR, 'requests.json');

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR);
if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, '[]');

const app = express();
app.use(cors());
app.use(express.json());

function readData() {
  return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8') || '[]');
}

function writeData(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

app.get('/api/requests', (req, res) => {
  res.json(readData());
});

app.post('/api/requests', (req, res) => {
  const requests = readData();
  const item = req.body;
  requests.push(item);
  writeData(requests);
  res.status(201).json(item);
});

app.put('/api/requests/:id', (req, res) => {
  const requests = readData();
  const idx = requests.findIndex(r => r.id === req.params.id);
  if (idx === -1) return res.status(404).send('Not found');
  requests[idx] = { ...requests[idx], ...req.body };
  writeData(requests);
  res.json(requests[idx]);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
