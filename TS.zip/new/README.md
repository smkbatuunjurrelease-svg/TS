# Teacher Substitution System — Local Run Guide

This repository is a single-file client app (`teacher.html`) that reads data from public Google Sheets and simulates writes in the browser. A minimal example API server is included under `server/` to demonstrate how you could add server-side persistence.

Quick steps to run the UI + example API server (PowerShell)

1) Start the example API server (optional — recommended for persistence):

```powershell
cd 'c:\Users\Surface Pro 7 Plus\Downloads\new\server'
npm install
npm start
# server listens on http://localhost:3000
```

2) Serve the static UI and open it in a browser:

```powershell
cd 'c:\Users\Surface Pro 7 Plus\Downloads\new'
python -m http.server 8000
# open http://localhost:8000/teacher.html
```

What the server does
- The example server persists requests to `server/data/requests.json` and exposes:
  - `GET /api/requests` — returns all saved requests
  - `POST /api/requests` — append a request (JSON body)
  - `PUT /api/requests/:id` — update a request by `id`

How the UI loads data
- The UI (in `teacher.html`) reads configuration and data from public Google Sheets via opensheet.elk.sh using the `GOOGLE_SHEET_ID` constant near the top of the file.
- The sheet tabs it expects are:
  - `TeacherNameID` (columns: `Teachers_ID`, `Teacher_Name`, `Email`)
  - `Form Responses 1` (requests)
  - `TimeTable` (Time column)
  - `Subject` (Subject column)
  - `Reasons` (Reason column)
  - `Status` (Status column)

How to add a new teacher (correct and immediate way)
1. Open the Google Sheet referenced by `GOOGLE_SHEET_ID` (value in `teacher.html`).
2. Open the `TeacherNameID` tab.
3. Add a new row with exactly these column names (case-sensitive):

| Teachers_ID | Teacher_Name     | Email               |
|-------------|------------------|---------------------|
| TCHR009     | John Example     | john@example.com    |

4. Save the sheet. In the UI reload the page (or press the browser refresh button). The new teacher will appear in the `Select Your Name` dropdown.

Notes about admin users and IDs
- The app treats the teacher with `Teachers_ID` equal to `ADMIN001` as an admin (see `loginUser()` in `teacher.html`). If you want someone to have admin privileges, set their `Teachers_ID` to `ADMIN001`.

Local / offline alternative (developer convenience)
- If you cannot or do not want to modify the Google Sheet, you can add a teacher locally for quick testing by editing `teacher.html`:
  - Find the `loadAllData()` function and after `appData.teachers = ...` temporarily add a hardcoded teacher object, for example:

```js
appData.teachers.push({ id: 'LOCAL001', name: 'Local Teacher', email: 'local@example.com', available: true });
```

- This only affects your local copy and is useful for developing without changing the live sheet. Remove the line before committing.

Extending the example server
- The example server only stores requests. If you want to manage teachers via the server as well, you can:
  - Add a `server/data/teachers.json` file and API endpoints `GET /api/teachers`, `POST /api/teachers`, etc.; and
  - Update `teacher.html` to fetch teachers from `http://localhost:3000/api/teachers` instead of the Google Sheet.

Managing teachers via the local example server
- This repo includes teacher-management endpoints on the example server. When the server is running the UI will prefer teachers from `http://localhost:3000/api/teachers` and the Admin view exposes a "Teachers Management" table.

Example server endpoints:
- `GET /api/teachers` — list teachers
- `POST /api/teachers` — create teacher (JSON: `{ id?, name, email?, isAdmin? }`)
- `PUT /api/teachers/:id` — update teacher
- `DELETE /api/teachers/:id` — delete teacher

Quick example (PowerShell) to add a teacher via the API:

```powershell
Invoke-RestMethod -Method POST -Uri http://localhost:3000/api/teachers -ContentType 'application/json' -Body (@{ name = 'New Teacher'; email = 'new@example.com'; isAdmin = $false } | ConvertTo-Json)
```

Security & production notes
- The example server is intentionally minimal and uses file-based storage. For production, add authentication, validation, and replace file storage with a database or the Google Sheets API with proper credentials and rate-limit handling.

If you want, I can:
- Patch `teacher.html` to fetch teachers from the example server when present and add server endpoints to manage teachers, or
- Prepare a small PR message documenting these changes.
